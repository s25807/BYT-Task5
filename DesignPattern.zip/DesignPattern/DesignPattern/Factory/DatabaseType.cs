﻿
namespace DesignPattern.Factory
{
    public enum DatabaseType
    {
        SqlServer,
        Oracle
    }
}
