﻿namespace DesignPattern.Factory
{
    public static class DatabaseFactory
    {
        //public static IDatabase CreateDatabase(...)
        //{
        //  ...
        //}
    }
}
