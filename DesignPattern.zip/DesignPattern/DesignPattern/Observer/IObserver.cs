﻿

namespace DesignPattern.Observer
{
    public interface IObserver
    {
        void Update(string availability);
    }
}
